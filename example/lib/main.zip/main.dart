import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:bg_location_tracker/bg_location_tracker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MyApp());
}

class AppState extends ChangeNotifier {
  bool isLoggedIn = false;
  TrackingState trackingState =
      const TrackingState(status: TrackingStatus.idle);
  PermissionStatus? permissions;
  List<LocationPoint> currentLocations = [];
  List<dynamic> serverLocations = [];

  String serverIp = '192.168.0.127';
  String currentUserId = 'user123';
  String get baseUrl => 'http://$serverIp:3000';
  late SharedPreferences _prefs;

  String selectedDateFilter = 'Today'; // Today, Week, Month, All
  String selectedUserFilter = 'All Users';

  AppState() {
    _init();
  }

  Future<void> _init() async {
    _prefs = await SharedPreferences.getInstance();
    serverIp = _prefs.getString('serverIp') ?? serverIp;
    currentUserId = _prefs.getString('currentUserId') ?? 'user123';
    isLoggedIn = _prefs.getBool('isLoggedIn') ?? false;

    // 1. Initialize Native Plugin
    // This allows passing global tracking rules like notifications.
    await BackgroundLocationTracker.instance.initialize(
      const TrackerOptions(
        notification: NotificationOptions(
          title: 'Field Tracking',
          text: 'Recording location securely',
          showStopAction: true,
        ),
        debugLogs: true,
      ),
    );

    permissions = await BackgroundLocationTracker.instance.checkPermissions();
    trackingState = await BackgroundLocationTracker.instance.getTrackingState();

    // If the native plugin says it's tracking, ensure UI reflects it
    if (trackingState.status != TrackingStatus.idle) {
      isLoggedIn = true;
    }

    if (isLoggedIn) {
      _listenToStreams();
      await fetchServerData();
    }

    notifyListeners();
  }

  List<String> get availableUsers {
    final users = serverLocations
        .map((loc) => loc['userId']?.toString() ?? 'Unknown')
        .toSet()
        .toList();
    return ['All Users', ...users];
  }

  void updateDateFilter(String filter) {
    selectedDateFilter = filter;
    notifyListeners();
  }

  void updateUserFilter(String user) {
    selectedUserFilter = user;
    notifyListeners();
  }

  // List<dynamic> get filteredLocations {
  //   final now = DateTime.now();
  //   var filtered = serverLocations.where((loc) {
  //     // User Filter
  //     if (selectedUserFilter != 'All Users') {
  //       final locUser = loc['userId']?.toString() ?? 'Unknown';
  //       if (locUser != selectedUserFilter) return false;
  //     }

  //     // Date Filter
  //     if (loc['timestamp'] == null) return false;
  //     final dt = DateTime.fromMillisecondsSinceEpoch(loc['timestamp'] as int);

  //     if (selectedDateFilter == 'Today') {
  //       return dt.year == now.year &&
  //           dt.month == now.month &&
  //           dt.day == now.day;
  //     } else if (selectedDateFilter == 'Week') {
  //       return now.difference(dt).inDays <= 7;
  //     } else if (selectedDateFilter == 'Month') {
  //       return now.difference(dt).inDays <= 30;
  //     }
  //     return true; // All
  //   }).toList();

  //   // Display latest data at the top
  //   filtered.sort((a, b) {
  //     final tA = a['timestamp'] as int? ?? 0;
  //     final tB = b['timestamp'] as int? ?? 0;
  //     return tB.compareTo(tA);
  //   });

  //   return filtered;
  // }
  List<dynamic> get filteredLocations {
    final now = DateTime.now();

    DateTime? parseTimestamp(dynamic value) {
      if (value == null) {
        return null;
      }

      // New format from Kotlin:
      // 2026-09-21T10:30:45.123Z
      if (value is String) {
        return DateTime.tryParse(value);
      }

      // Backward compatibility with old data
      // stored as epoch milliseconds.
      if (value is int) {
        return DateTime.fromMillisecondsSinceEpoch(value);
      }

      if (value is double) {
        return DateTime.fromMillisecondsSinceEpoch(
          value.toInt(),
        );
      }

      return null;
    }

    var filtered = serverLocations.where((loc) {
      // --------------------------------------------------
      // USER FILTER
      // --------------------------------------------------

      if (selectedUserFilter != 'All Users') {
        final locUser = loc['userId']?.toString() ?? 'Unknown';

        if (locUser != selectedUserFilter) {
          return false;
        }
      }

      // --------------------------------------------------
      // TIMESTAMP
      // --------------------------------------------------

      final dt = parseTimestamp(
        loc['timestamp'],
      );

      if (dt == null) {
        return false;
      }

      // Convert UTC timestamp to local time.
      final localDt = dt.toLocal();

      // --------------------------------------------------
      // DATE FILTER
      // --------------------------------------------------

      if (selectedDateFilter == 'Today') {
        return localDt.year == now.year &&
            localDt.month == now.month &&
            localDt.day == now.day;
      }

      if (selectedDateFilter == 'Week') {
        final startOfWeek = DateTime(
          now.year,
          now.month,
          now.day,
        ).subtract(
          Duration(days: now.weekday - 1),
        );

        return !localDt.isBefore(startOfWeek);
      }

      if (selectedDateFilter == 'Month') {
        final startOfMonth = DateTime(
          now.year,
          now.month,
          1,
        );

        return !localDt.isBefore(startOfMonth);
      }

      // All
      return true;
    }).toList();

    // --------------------------------------------------
    // SORT
    // Latest location first
    // --------------------------------------------------

    filtered.sort((a, b) {
      final dateA = parseTimestamp(
        a['timestamp'],
      );

      final dateB = parseTimestamp(
        b['timestamp'],
      );

      if (dateA == null && dateB == null) {
        return 0;
      }

      if (dateA == null) {
        return 1;
      }

      if (dateB == null) {
        return -1;
      }

      return dateB.compareTo(dateA);
    });

    return filtered;
  }

  Future<void> loginWithJsonConfig(
      String modeTitle, Map<String, dynamic> jsonResponse) async {
    try {
      // 1. Save IP & User ID
      await _prefs.setString('serverIp', serverIp);
      await _prefs.setString('currentUserId', currentUserId);

      // 2. We simulate the JSON response from your login endpoint.
      // Your backend should return the `TrackingConfig` and `UploadConfig` structure.
      final configMap = jsonResponse['tracking_config'] as Map<String, dynamic>;
      final uploadMap = jsonResponse['upload_config'] as Map<String, dynamic>;

      // 3. Request permissions if needed
      if (permissions?.location == LocationPermissionLevel.denied) {
        permissions =
            await BackgroundLocationTracker.instance.requestPermissions();
        if (permissions?.location == LocationPermissionLevel.denied) {
          return; // User denied
        }
      }

      // 4. Record login in json-server (Mock backend)
      await http.post(
        Uri.parse('$baseUrl/login_history'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'timestamp': DateTime.now().toIso8601String(),
          'mode': modeTitle,
          'userId': currentUserId
        }),
      );

      // 5. Initialize Upload Config from JSON
      // This configures the native HTTP client (headers, URL, batching).
      // If internet drops, native SQLite saves it, and the native JobScheduler uploads when online.
      await BackgroundLocationTracker.instance.configureUpload(
        UploadConfig(
          url: uploadMap['url'] ?? '$baseUrl/locations',
          method: uploadMap['method'] ?? 'POST',
          headers: {
            ...Map<String, String>.from(uploadMap['headers'] ?? {}),
            'userId': currentUserId, // Native will inject this into payload
          },
          batchSize: uploadMap['batchSize'] ?? 1,
          syncIntervalSeconds: uploadMap['syncIntervalSeconds'] ?? 15,
        ),
      );

      // 6. Start Tracking natively based on JSON
      final trackingConfig = TrackingConfig.fromMap(configMap);
      await BackgroundLocationTracker.instance.start(trackingConfig);

      trackingState =
          await BackgroundLocationTracker.instance.getTrackingState();

      isLoggedIn = true;
      await _prefs.setBool('isLoggedIn', true);

      _listenToStreams();
      await fetchServerData();
    } catch (e) {
      debugPrint('Network/JSON error: $e');
    }
  }

  Future<void> logout() async {
    if (trackingState.status != TrackingStatus.idle) {
      await BackgroundLocationTracker.instance.stop(flushUpload: true);
    }
    await BackgroundLocationTracker.instance.clearUploadConfig();

    isLoggedIn = false;
    await _prefs.setBool('isLoggedIn', false);

    currentLocations.clear();
    serverLocations.clear();
    notifyListeners();
  }

  // Future<void> fetchServerData() async {
  //   try {
  //     final locRes = await http.get(Uri.parse('$baseUrl/locations'));
  //     if (locRes.statusCode == 200) {
  //       serverLocations = jsonDecode(locRes.body);
  //       debugPrint(
  //           'FLUTTER LOG: Fetched ${serverLocations.length} locations from json-server API.');
  //     }
  //     notifyListeners();
  //   } catch (e) {
  //     debugPrint('FLUTTER LOG: Failed to fetch from server (Offline?): $e');
  //   }
  // }
  Future<void> fetchServerData() async {
    try {
      final userId = currentUserId;

      if (userId == null || userId.isEmpty) {
        debugPrint(
          'FLUTTER LOG: Cannot fetch locations. User ID is missing.',
        );
        return;
      }

      final uri = Uri.parse(
        '$baseUrl/locations',
      ).replace(
        queryParameters: {
          'userId': userId,
        },
      );

      debugPrint(
        'FLUTTER LOG: Fetching locations for userId=$userId',
      );

      final locRes = await http.get(uri);

      if (locRes.statusCode == 200) {
        final decoded = jsonDecode(locRes.body);

        if (decoded is List) {
          serverLocations = List<Map<String, dynamic>>.from(
            decoded,
          );

          debugPrint(
            'FLUTTER LOG: Fetched '
            '${serverLocations.length} locations '
            'for userId=$userId',
          );
        } else {
          debugPrint(
            'FLUTTER LOG: Unexpected API response format.',
          );

          serverLocations = [];
        }
      } else {
        debugPrint(
          'FLUTTER LOG: Failed to fetch locations. '
          'Status code: ${locRes.statusCode}',
        );
      }

      notifyListeners();
    } catch (e) {
      debugPrint(
        'FLUTTER LOG: Failed to fetch from server: $e',
      );
    }
  }

  Future<void> clearAllData() async {
    // Delete only the filtered ones, or all of them?
    // Usually "Clear Data" clears everything, but let's clear the filtered ones so users can clear just one user's data if they want, or all if 'All Users' is selected.
    final listToDelete = List.from(filteredLocations);

    // Optimistically update UI
    serverLocations.removeWhere((item) => listToDelete.contains(item));
    notifyListeners();

    for (var loc in listToDelete) {
      final id = loc['id'];
      if (id != null) {
        try {
          await http.delete(Uri.parse('$baseUrl/locations/$id'));
        } catch (_) {}
      }
    }
  }

  void _listenToStreams() {
    BackgroundLocationTracker.instance.locationStream.listen((point) {
      debugPrint(
          'FLUTTER LOG: Location captured via stream -> Lat: ${point.latitude}, Lng: ${point.longitude}');
      currentLocations.add(point);
      fetchServerData(); // Instant refetch to update UI since we push to server instantly on capture
      notifyListeners();
    });

    BackgroundLocationTracker.instance.stateStream.listen((state) {
      trackingState = state;
      notifyListeners();
    });
  }

  Future<void> openSettings() async {
    await BackgroundLocationTracker.instance.openAppSettings();
  }

  Future<void> recheckPermissions() async {
    permissions = await BackgroundLocationTracker.instance.checkPermissions();
    notifyListeners();
  }
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: _appState,
      builder: (context, _) {
        return MaterialApp(
          title: 'Tracking App',
          theme: ThemeData(
            colorScheme: ColorScheme.fromSeed(seedColor: Colors.indigo),
            useMaterial3: true,
          ),
          home: _appState.isLoggedIn
              ? const DashboardScreen()
              : const LoginScreen(),
        );
      },
    );
  }
}

final AppState _appState = AppState();

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  late TextEditingController _ipController;
  late TextEditingController _userController;

  @override
  void initState() {
    super.initState();
    _ipController = TextEditingController(text: _appState.serverIp);
    _userController = TextEditingController(text: _appState.currentUserId);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Login & Setup Tracker')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Row(
              children: [
                Expanded(
                  flex: 2,
                  child: TextField(
                    controller: _ipController,
                    decoration: const InputDecoration(
                      labelText: 'JSON Server IP',
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.wifi),
                    ),
                    onChanged: (val) => _appState.serverIp = val,
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  flex: 1,
                  child: TextField(
                    controller: _userController,
                    decoration: const InputDecoration(
                      labelText: 'User ID',
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.person),
                    ),
                    onChanged: (val) => _appState.currentUserId = val,
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              children: [
                _buildJsonScenarioCard(context,
                    title: 'A. Every Minute (Periodic)',
                    desc: 'Captures location strictly every 60 seconds.',
                    icon: Icons.timer,
                    jsonPayload: {
                      "tracking_config": {
                        "mode": "periodic",
                        "intervalSeconds": 60,
                        "accuracy": "high"
                      },
                      "upload_config": {
                        "headers": {"Authorization": "Bearer fake_token_123"},
                        "batchSize": 1
                      }
                    }),
                _buildJsonScenarioCard(context,
                    title: 'B. Every 200 Meters (Distance)',
                    desc: 'Updates only when user moves 200m. Saves battery.',
                    icon: Icons.social_distance,
                    jsonPayload: {
                      "tracking_config": {
                        "mode": "distanceFilter",
                        "minDistanceMeters": 200,
                        "accuracy": "balanced"
                      },
                      "upload_config": {
                        "headers": {"Authorization": "Bearer fake_token_123"},
                        "batchSize": 1
                      }
                    }),
                _buildJsonScenarioCard(context,
                    title: 'C. Shift Timings (Mon-Fri 9-5)',
                    desc: 'Tracks based on schedule even if app is closed.',
                    icon: Icons.work,
                    jsonPayload: {
                      "tracking_config": {
                        "mode": "schedule",
                        "accuracy": "balanced",
                        "schedule": [
                          {"day": 1, "startHour": 9, "endHour": 17}, // Mon
                          {"day": 2, "startHour": 9, "endHour": 17}, // Tue
                          {"day": 3, "startHour": 9, "endHour": 17}, // Wed
                          {"day": 4, "startHour": 9, "endHour": 17}, // Thu
                          {"day": 5, "startHour": 9, "endHour": 17} // Fri
                        ]
                      },
                      "upload_config": {
                        "headers": {"Authorization": "Bearer fake_token_123"},
                        "batchSize": 1
                      }
                    }),
                _buildJsonScenarioCard(context,
                    title: 'D. Walking vs Driving (Adaptive)',
                    desc:
                        'Motion-based. Fast when driving, slow when walking/stopped.',
                    icon: Icons.directions_car,
                    jsonPayload: {
                      "tracking_config": {
                        "mode": "adaptive",
                        "detectStops": true,
                        "stopRadiusMeters": 50,
                        "stopMinDurationSeconds": 180
                      },
                      "upload_config": {
                        "headers": {"Authorization": "Bearer fake_token_123"},
                        "batchSize": 1
                      }
                    }),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildJsonScenarioCard(
    BuildContext context, {
    required String title,
    required String desc,
    required IconData icon,
    required Map<String, dynamic> jsonPayload,
  }) {
    return Card(
      elevation: 3,
      margin: const EdgeInsets.only(bottom: 16),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon, size: 30, color: Theme.of(context).primaryColor),
                const SizedBox(width: 16),
                Expanded(
                    child: Text(title,
                        style: Theme.of(context)
                            .textTheme
                            .titleMedium
                            ?.copyWith(fontWeight: FontWeight.bold))),
              ],
            ),
            const SizedBox(height: 8),
            Text(desc, style: Theme.of(context).textTheme.bodyMedium),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: () =>
                    _appState.loginWithJsonConfig(title, jsonPayload),
                icon: const Icon(Icons.login),
                label: const Text('Login via JSON Response'),
              ),
            )
          ],
        ),
      ),
    );
  }
}

// class DashboardScreen extends StatelessWidget {
//   const DashboardScreen({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return ListenableBuilder(
//       listenable: _appState,
//       builder: (context, _) {
//         final state = _appState.trackingState;
//         final hasPending = state.pendingUpload > 0;

//         final hasAlways =
//             _appState.permissions?.location == LocationPermissionLevel.always;
//         final hasBatteryOptDisabled =
//             _appState.permissions?.batteryOptimizationIgnored == true;

//         return Scaffold(
//           appBar: AppBar(
//             title: Text('Dashboard - ${_appState.currentUserId}'),
//             actions: [
//               IconButton(
//                 icon: const Icon(Icons.delete_outline, color: Colors.redAccent),
//                 onPressed: () => _appState.clearAllData(),
//                 tooltip: 'Clear Filtered Data',
//               ),
//               IconButton(
//                 icon: const Icon(Icons.refresh),
//                 onPressed: _appState.fetchServerData,
//                 tooltip: 'Refresh Server Data',
//               ),
//               IconButton(
//                 icon: const Icon(Icons.logout),
//                 onPressed: _appState.logout,
//                 tooltip: 'Logout',
//               ),
//             ],
//           ),
//           body: Padding(
//             padding: const EdgeInsets.all(16.0),
//             child: Column(
//               crossAxisAlignment: CrossAxisAlignment.stretch,
//               children: [
//                 // SPECIFIC PERMISSION WARNINGS
//                 if (!hasAlways || !hasBatteryOptDisabled)
//                   Container(
//                     margin: const EdgeInsets.only(bottom: 16),
//                     padding: const EdgeInsets.all(12),
//                     decoration: BoxDecoration(
//                         color: Colors.red.shade100,
//                         borderRadius: BorderRadius.circular(8)),
//                     child: Column(
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       children: [
//                         const Text('⚠️ Background Restrictions Found',
//                             style: TextStyle(
//                                 fontWeight: FontWeight.bold,
//                                 color: Colors.red)),
//                         const SizedBox(height: 4),
//                         if (!hasAlways)
//                           const Text(
//                               '• Location must be set to "Allow all the time" in App Info > Permissions.'),
//                         if (!hasBatteryOptDisabled)
//                           const Text(
//                               '• Battery Saver / Optimization must be disabled for this app.'),
//                         const SizedBox(height: 8),
//                         Row(
//                           children: [
//                             ElevatedButton(
//                               onPressed: () => _appState.openSettings(),
//                               child: const Text('Open App Settings'),
//                             ),
//                             const Spacer(),
//                             TextButton(
//                               onPressed: () => _appState.recheckPermissions(),
//                               child: const Text('Re-check'),
//                             ),
//                           ],
//                         )
//                       ],
//                     ),
//                   ),

//                 // OFFLINE / ONLINE INDICATOR
//                 Container(
//                   padding: const EdgeInsets.all(12),
//                   decoration: BoxDecoration(
//                       color: hasPending
//                           ? Colors.orange.shade100
//                           : Colors.green.shade100,
//                       borderRadius: BorderRadius.circular(8)),
//                   child: Row(
//                     children: [
//                       Icon(hasPending ? Icons.cloud_off : Icons.cloud_done,
//                           color: hasPending ? Colors.orange : Colors.green),
//                       const SizedBox(width: 12),
//                       Expanded(
//                         child: Text(hasPending
//                             ? 'Offline: Storing ${state.pendingUpload} points locally in Native DB. Will sync when online.'
//                             : 'Online: All points synced seamlessly!'),
//                       ),
//                     ],
//                   ),
//                 ),
//                 const SizedBox(height: 16),

//                 // Status Stats
//                 Row(
//                   children: [
//                     Expanded(
//                         child:
//                             _StatCard('Captured', '${state.pointsCaptured}')),
//                     const SizedBox(width: 8),
//                     Expanded(
//                         child: _StatCard('Synced',
//                             '${state.pointsCaptured - state.pendingUpload}')),
//                     const SizedBox(width: 8),
//                     Expanded(
//                         child: _StatCard('Pending', '${state.pendingUpload}')),
//                   ],
//                 ),
//                 const SizedBox(height: 16),

//                 // Filters Dropdowns
//                 Row(
//                   mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                   children: [
//                     Text('Data (${_appState.filteredLocations.length})',
//                         style: Theme.of(context).textTheme.titleMedium),
//                     Row(
//                       children: [
//                         DropdownButton<String>(
//                           value: _appState.availableUsers
//                                   .contains(_appState.selectedUserFilter)
//                               ? _appState.selectedUserFilter
//                               : 'All Users',
//                           items: _appState.availableUsers.map((String value) {
//                             return DropdownMenuItem<String>(
//                               value: value,
//                               child: Text(value),
//                             );
//                           }).toList(),
//                           onChanged: (val) {
//                             if (val != null) _appState.updateUserFilter(val);
//                           },
//                         ),
//                         const SizedBox(width: 16),
//                         DropdownButton<String>(
//                           value: _appState.selectedDateFilter,
//                           items: ['Today', 'Week', 'Month', 'All']
//                               .map((String value) {
//                             return DropdownMenuItem<String>(
//                               value: value,
//                               child: Text(value),
//                             );
//                           }).toList(),
//                           onChanged: (val) {
//                             if (val != null) _appState.updateDateFilter(val);
//                           },
//                         ),
//                       ],
//                     ),
//                   ],
//                 ),
//                 const SizedBox(height: 8),

//                 // GET Call Display (JSON Server Data)
//                 Expanded(
//                   child: Card(
//                     child: ListView.builder(
//                       itemCount: _appState.filteredLocations.length,
//                       itemBuilder: (c, i) {
//                         final loc = _appState.filteredLocations[i];
//                         final ts = loc['timestamp'] as int?;
//                         final formattedTime = ts != null
//                             ? DateFormat('MMM dd, yyyy - hh:mm:ss a')
//                                 .format(DateTime.fromMillisecondsSinceEpoch(ts))
//                             : 'Unknown';

//                         final uId = loc['userId'] ?? 'Unknown';

//                         return ListTile(
//                           leading: CircleAvatar(
//                             child: Text(
//                                 uId.toString().substring(0, 1).toUpperCase()),
//                           ),
//                           title: Text(
//                               '[$uId] Lat: ${loc['latitude']?.toStringAsFixed(5)}, Lng: ${loc['longitude']?.toStringAsFixed(5)}'),
//                           subtitle: Text(formattedTime),
//                         );
//                       },
//                     ),
//                   ),
//                 )
//               ],
//             ),
//           ),
//         );
//       },
//     );
//   }
// }

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  DateTime? _parseTimestamp(dynamic value) {
    if (value == null) return null;

    // New native format:
    // 2026-09-21T10:30:45.123Z
    if (value is String) {
      return DateTime.tryParse(value);
    }

    // Backward compatibility with old epoch-millisecond data.
    if (value is int) {
      return DateTime.fromMillisecondsSinceEpoch(value);
    }

    // Sometimes JSON numbers may arrive as double.
    if (value is double) {
      return DateTime.fromMillisecondsSinceEpoch(value.toInt());
    }

    return null;
  }

  String _formatTimestamp(dynamic value) {
    final dateTime = _parseTimestamp(value);

    if (dateTime == null) {
      return 'Unknown';
    }

    return DateFormat(
      'MMM dd, yyyy - hh:mm:ss a',
    ).format(dateTime.toLocal());
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: _appState,
      builder: (context, _) {
        final state = _appState.trackingState;

        final hasPending = state.pendingUpload > 0;

        final hasAlways =
            _appState.permissions?.location == LocationPermissionLevel.always;

        final hasBatteryOptDisabled =
            _appState.permissions?.batteryOptimizationIgnored == true;

        return Scaffold(
          appBar: AppBar(
            title: Text(
              'Dashboard - ${_appState.currentUserId}',
            ),
            actions: [
              IconButton(
                icon: const Icon(
                  Icons.delete_outline,
                  color: Colors.redAccent,
                ),
                onPressed: () => _appState.clearAllData(),
                tooltip: 'Clear Filtered Data',
              ),
              IconButton(
                icon: const Icon(Icons.refresh),
                onPressed: _appState.fetchServerData,
                tooltip: 'Refresh Server Data',
              ),
              IconButton(
                icon: const Icon(Icons.logout),
                onPressed: _appState.logout,
                tooltip: 'Logout',
              ),
            ],
          ),
          body: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // ---------------------------------------------------------
                // PERMISSION WARNINGS
                // ---------------------------------------------------------
                if (!hasAlways || !hasBatteryOptDisabled)
                  Container(
                    margin: const EdgeInsets.only(bottom: 16),
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.red.shade100,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          '⚠️ Background Restrictions Found',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: Colors.red,
                          ),
                        ),
                        const SizedBox(height: 4),
                        if (!hasAlways)
                          const Text(
                            '• Location must be set to '
                            '"Allow all the time" in '
                            'App Info > Permissions.',
                          ),
                        if (!hasBatteryOptDisabled)
                          const Text(
                            '• Battery Saver / Optimization must '
                            'be disabled for this app.',
                          ),
                        const SizedBox(height: 8),
                        Row(
                          children: [
                            ElevatedButton(
                              onPressed: () => _appState.openSettings(),
                              child: const Text(
                                'Open App Settings',
                              ),
                            ),
                            const Spacer(),
                            TextButton(
                              onPressed: () => _appState.recheckPermissions(),
                              child: const Text(
                                'Re-check',
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),

                // ---------------------------------------------------------
                // OFFLINE / ONLINE
                // ---------------------------------------------------------
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: hasPending
                        ? Colors.orange.shade100
                        : Colors.green.shade100,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Row(
                    children: [
                      Icon(
                        hasPending ? Icons.cloud_off : Icons.cloud_done,
                        color: hasPending ? Colors.orange : Colors.green,
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          hasPending
                              ? 'Offline: Storing '
                                  '${state.pendingUpload} points locally '
                                  'in Native DB. Will sync when online.'
                              : 'Online: All points synced seamlessly!',
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 16),

                // ---------------------------------------------------------
                // STATS
                // ---------------------------------------------------------
                Row(
                  children: [
                    Expanded(
                      child: _StatCard(
                        'Captured',
                        '${state.pointsCaptured}',
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: _StatCard(
                        'Synced',
                        '${state.pointsCaptured - state.pendingUpload}',
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: _StatCard(
                        'Pending',
                        '${state.pendingUpload}',
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 16),

                // ---------------------------------------------------------
                // FILTERS
                // ---------------------------------------------------------
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Data (${_appState.filteredLocations.length})',
                      style: Theme.of(context).textTheme.titleMedium,
                    ),
                    Row(
                      children: [
                        DropdownButton<String>(
                          value: _appState.availableUsers
                                  .contains(_appState.selectedUserFilter)
                              ? _appState.selectedUserFilter
                              : 'All Users',
                          items: _appState.availableUsers.map(
                            (String value) {
                              return DropdownMenuItem<String>(
                                value: value,
                                child: Text(value),
                              );
                            },
                          ).toList(),
                          onChanged: (val) {
                            if (val != null) {
                              _appState.updateUserFilter(val);
                            }
                          },
                        ),
                        const SizedBox(width: 16),
                        DropdownButton<String>(
                          value: _appState.selectedDateFilter,
                          items: [
                            'Today',
                            'Week',
                            'Month',
                            'All',
                          ].map(
                            (String value) {
                              return DropdownMenuItem<String>(
                                value: value,
                                child: Text(value),
                              );
                            },
                          ).toList(),
                          onChanged: (val) {
                            if (val != null) {
                              _appState.updateDateFilter(val);
                            }
                          },
                        ),
                      ],
                    ),
                  ],
                ),

                const SizedBox(height: 8),

                // ---------------------------------------------------------
                // SERVER DATA
                // ---------------------------------------------------------
                Expanded(
                  child: Card(
                    child: ListView.builder(
                      itemCount: _appState.filteredLocations.length,
                      itemBuilder: (context, index) {
                        final loc = _appState.filteredLocations[index];

                        final timestamp = loc['timestamp'];

                        final formattedTime = _formatTimestamp(timestamp);

                        final userId = loc['userId']?.toString() ?? 'Unknown';

                        final latitude = loc['latitude'];

                        final longitude = loc['longitude'];

                        final accuracy = loc['accuracy'];

                        final userInitial = userId.isNotEmpty
                            ? userId.substring(0, 1).toUpperCase()
                            : '?';

                        return ListTile(
                          leading: CircleAvatar(
                            child: Text(userInitial),
                          ),
                          title: Text(
                            '[$userId] '
                            'Lat: ${_formatCoordinate(latitude)}, '
                            'Lng: ${_formatCoordinate(longitude)}',
                          ),
                          subtitle: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(formattedTime),
                              if (accuracy != null)
                                Text(
                                  'Accuracy: '
                                  '${_formatAccuracy(accuracy)} m',
                                ),
                            ],
                          ),
                        );
                      },
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  String _formatCoordinate(dynamic value) {
    if (value == null) {
      return 'Unknown';
    }

    final number = double.tryParse(
      value.toString(),
    );

    if (number == null) {
      return 'Unknown';
    }

    return number.toStringAsFixed(5);
  }

  String _formatAccuracy(dynamic value) {
    if (value == null) {
      return 'Unknown';
    }

    final number = double.tryParse(
      value.toString(),
    );

    if (number == null) {
      return 'Unknown';
    }

    return number.toStringAsFixed(1);
  }
}

class _StatCard extends StatelessWidget {
  final String label;
  final String value;

  const _StatCard(
    this.label,
    this.value,
  );

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.symmetric(
          vertical: 16.0,
        ),
        child: Column(
          children: [
            Text(
              value,
              style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
            ),
            Text(
              label,
              style: Theme.of(context).textTheme.bodySmall,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }
}

// class _StatCard extends StatelessWidget {
//   final String label;
//   final String value;
//   const _StatCard(this.label, this.value);

//   @override
//   Widget build(BuildContext context) {
//     return Card(
//       child: Padding(
//         padding: const EdgeInsets.symmetric(vertical: 16.0),
//         child: Column(
//           children: [
//             Text(value,
//                 style: Theme.of(context)
//                     .textTheme
//                     .headlineMedium
//                     ?.copyWith(fontWeight: FontWeight.bold)),
//             Text(label,
//                 style: Theme.of(context).textTheme.bodySmall,
//                 overflow: TextOverflow.ellipsis),
//           ],
//         ),
//       ),
//     );
//   }
// }
