package com.example.bg_location_tracker.sync

import android.content.Context
import android.util.Log
import com.example.bg_location_tracker.store.ConfigStore
import com.example.bg_location_tracker.store.LocationDatabase
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.time.Instant
import java.time.ZoneId
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter

class UploadManager(
    private val context: Context
) {

    companion object {
        private const val TAG = "BgLocationTracker"

        private const val CONNECT_TIMEOUT = 15_000
        private const val READ_TIMEOUT = 30_000
    }

    private val db = LocationDatabase.getInstance(context)
    private val config = ConfigStore(context)

    /**
     * ISO-8601 UTC format.
     *
     * Example:
     * 2026-09-21T10:30:45.123Z
     */
    private val utcFormatter =
        DateTimeFormatter
            .ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
            .withZone(ZoneId.of("UTC"))

    private val localFormatter =
        DateTimeFormatter
            .ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSXXX")
            .withZone(ZoneId.systemDefault())

    fun sync(): Boolean {

        val urlStr = config.syncUrl

        // No sync URL configured.
        if (urlStr.isNullOrBlank()) {
            Log.d(TAG, "Sync URL is not configured")
            return true
        }

        val locations = db.getUnsynced(config.batchSize)

        // Nothing to upload.
        if (locations.isEmpty()) {
            Log.d(TAG, "No unsynced locations")
            return true
        }

        var connection: HttpURLConnection? = null

        try {

            /*
             * Parse headers only once.
             */
            val headersJson = config.syncHeaders
                ?.takeIf { it.isNotBlank() }
                ?.let {
                    try {
                        JSONObject(it)
                    } catch (e: Exception) {
                        Log.e(
                            TAG,
                            "Invalid syncHeaders JSON: ${e.message}"
                        )
                        null
                    }
                }

            /*
             * Extract userId if your configuration
             * stores it inside syncHeaders.
             */
            val userId = headersJson
                ?.optString("userId")
                ?.takeIf { it.isNotBlank() }

            /*
             * Build payload.
             */
            val jsonArray = JSONArray()

            locations.forEach { loc ->

                val instant = Instant.ofEpochMilli(loc.time)

                val timestampString =
                    utcFormatter.format(instant)

                val timestampLocal =
                    localFormatter.format(instant)

                val obj = JSONObject().apply {

                    put("id", loc.id)

                    put(
                        "latitude",
                        loc.latitude
                    )

                    put(
                        "longitude",
                        loc.longitude
                    )

                    put(
                        "accuracy",
                        loc.accuracy
                    )

                    /*
                     * Send formatted timestamp.
                     *
                     * Example:
                     * 2026-09-21T10:30:45.123Z
                     */
                    put(
                        "timestamp",
                        loc.time
                    )

                    // UTC
                    put(
                        "timestampString",
                        timestampString
                    )

                    // Device local time with timezone offset
                    put(
                        "timestampLocal",
                        timestampLocal
                    )

                    put(
                        "saved_from",
                        "Native"
                    )

                    put(
                        "platform",
                        "Android"
                    )

                    if (!userId.isNullOrEmpty()) {
                        put(
                            "userId",
                            userId
                        )
                    }
                }

                jsonArray.put(obj)
            }

            /*
             * json-server does not natively support
             * inserting multiple records by POSTing
             * an array to /locations.
             *
             * Therefore:
             *
             * batchSize == 1
             *     -> send object
             *
             * batchSize > 1
             *     -> send array only if your backend
             *        explicitly supports bulk insertion.
             */
            val payload: String =
                if (locations.size == 1) {
                    jsonArray
                        .getJSONObject(0)
                        .toString()
                } else {
                    jsonArray.toString()
                }

            Log.d(
                TAG,
                "Uploading ${locations.size} location(s) to $urlStr"
            )

            /*
             * Open connection.
             */
            val url = URL(urlStr)

            connection =
                url.openConnection() as HttpURLConnection

            connection.apply {

                requestMethod = "POST"

                connectTimeout =
                    CONNECT_TIMEOUT

                readTimeout =
                    READ_TIMEOUT

                doOutput = true

                doInput = true

                useCaches = false

                setRequestProperty(
                    "Content-Type",
                    "application/json"
                )

                setRequestProperty(
                    "Accept",
                    "application/json"
                )

                /*
                 * Apply custom headers.
                 */
                headersJson?.let { json ->

                    val keys = json.keys()

                    while (keys.hasNext()) {

                        val key = keys.next()

                        /*
                         * Don't send userId as an HTTP header
                         * if it is only application metadata.
                         */
                        if (key.equals(
                                "userId",
                                ignoreCase = true
                            )
                        ) {
                            continue
                        }

                        val value =
                            json.optString(key)

                        if (value.isNotEmpty()) {

                            setRequestProperty(
                                key,
                                value
                            )
                        }
                    }
                }
            }

            /*
             * Write request body.
             */
            OutputStreamWriter(
                connection.outputStream,
                Charsets.UTF_8
            ).use { writer ->

                writer.write(payload)
                writer.flush()
            }

            /*
             * Get HTTP response.
             */
            val responseCode =
                connection.responseCode

            Log.d(
                TAG,
                "API response: $responseCode"
            )

            /*
             * Read response body.
             */
            val responseStream =
                if (responseCode in 200..299) {
                    connection.inputStream
                } else {
                    connection.errorStream
                }

            val responseBody =
                responseStream?.let { stream ->

                    BufferedReader(
                        InputStreamReader(
                            stream,
                            Charsets.UTF_8
                        )
                    ).use { reader ->
                        reader.readText()
                    }

                } ?: ""

            Log.d(
                TAG,
                "API response body: $responseBody"
            )

            /*
             * Successful request.
             */
            if (responseCode in 200..299) {

                db.deleteSynced(
                    locations.map { it.id }
                )

                Log.d(
                    TAG,
                    "Successfully synced ${locations.size} location(s)"
                )

                return true
            }

            /*
             * Server returned an error.
             */
            Log.e(
                TAG,
                "API call failed. HTTP $responseCode"
            )

            return false

        } catch (e: Exception) {

            Log.e(
                TAG,
                "API call failed: ${e.message}",
                e
            )

            return false

        } finally {

            /*
             * Always release the connection.
             */
            connection?.disconnect()
        }
    }
}